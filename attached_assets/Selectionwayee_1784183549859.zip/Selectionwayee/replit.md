# Selection Way Bot

## Overview
A Telegram bot (Python, `python-telegram-bot` 21.6) that lets users browse "Selection Way" course batches and log in to extract video/PDF links from their enrolled courses via `backend.multistreaming.site`'s API.

## Stack
- Python 3.12
- `python-telegram-bot==21.6` (polling mode, not webhooks)
- `requests` for calling the external course API

## Running
- Workflow **Telegram Bot** runs `python selection.py` (long-running polling worker, console output — no web UI/port).
- Requires the `BOT_TOKEN` secret (Telegram bot token from BotFather). The bot reads it via `os.environ["BOT_TOKEN"]` and raises on startup if missing.

## Security note
The original imported code had the bot token hardcoded in `selection.py` and committed to the public GitHub repo. It has been moved to the `BOT_TOKEN` secret — the user was asked to revoke the old token via BotFather and provide a fresh one.

## User preferences
None recorded yet.
