---
name: mp4 video source element pitfall
description: Using <source> elements for mp4 fallback chains doesn't fire onerror on network failures — use video.src directly instead
---

Browsers only fall back to the next `<source>` element for *codec* incompatibility, not for network errors (403, timeout, CDN failure). Using multiple `<source>` elements with an `onerror` on the `<video>` element silently fails to retry on network errors.

**Why:** The SelectionWay CDN sometimes fails individual quality URLs; we need true JS fallback across quality tiers.
**How to apply:** Set `video.src = urls[0]` directly, listen for `error` on the video element, increment index and call `video.src = urls[idx]; video.load()` on each error. Never use `<source>` elements for fallback chains that need to recover from network errors.
