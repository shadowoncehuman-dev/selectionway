---
name: HLS CORS proxy (selectionwaylive CDN)
description: selectionwaylive.hranker.com never sends CORS headers; hls.js silently fails in non-Safari browsers without a proxy
---

The live/HLS CDN (`selectionwaylive.hranker.com`) returns no `Access-Control-Allow-Origin` header. hls.js uses XHR/fetch to load playlists and segments, so every non-Safari browser silently fails. Safari has native HLS support and doesn't use XHR so it's unaffected.

**Fix in place:** A ThreadingHTTPServer proxy runs on port 8080 inside the bot process, started as a daemon thread at startup. It rewrites two levels of relative m3u8 URIs to absolute proxy URLs and adds `Access-Control-Allow-Origin: *` on all responses. The generated HTML wraps all HLS URLs via `proxied_hls_url()` which uses `REPLIT_DEV_DOMAIN` as the base.

**Why:** Only ~0.7% of lectures are HLS-only (5/733 in RRB Group D batch), but fully fixing them required a proxy since the CDN cannot be configured.
**How to apply:** `start_hls_proxy()` is called in `main()` before `run_polling()`. Port 8080 must be open in the workflow process.
