---
name: requests Accept-Encoding mismatch
description: Why copying a browser's Accept-Encoding header into Python `requests` calls can silently break JSON parsing.
---

Browser-captured request headers often include `Accept-Encoding: gzip, deflate, br, zstd`. Python's `requests`
(via urllib3) only auto-decodes brotli (`br`) or zstd if the optional `brotli`/`brotlicffi`/`zstandard` packages
are installed — by default they are not. When the server honors the advertised encoding and responds compressed,
`response.text`/`response.json()` gets raw compressed bytes, producing garbled text or
`json.decoder.JSONDecodeError: Expecting value: line 1 column 1 (char 0)` with no indication that compression is
the cause.

**Why:** Found while debugging a Telegram bot's login call to an external API — the request succeeded (HTTP 200)
but `response.json()` failed every time. `curl`-ing the same endpoint showed `Content-Encoding: br` and binary
garbage in the body once `br`/`zstd` were requested.

**How to apply:** When a scraped/copied header set includes `br` or `zstd` in `Accept-Encoding` and you see
JSON-decode errors on an otherwise-200 response, either strip `br`/`zstd` from the header (simplest — server
falls back to gzip/deflate or uncompressed) or install the matching decoder package. Prefer stripping the header
value over adding a new dependency.
