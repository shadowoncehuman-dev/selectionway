---
name: SQLite user DB schema
description: User tracking, rate limiting, and fetch logging for the SelectionWay bot stored in bot_data.db
---

Users table: user_id (PK), username, first_name, is_banned, fetch_limit, fetch_period ('day'/'week'/'month'/'unlimited'), joined_at.
Fetch log: id, user_id, batch_id, batch_name, fetched_at.

**Why:** Needed for per-user rate limiting, ban/unban, and admin audit of fetch history.
**How to apply:** `db_fetch_count_in_period()` counts rows in fetch_log within a rolling window (timedelta). Admins bypass rate limits entirely. `ADMIN_IDS` comes from the ADMIN_IDS env var/secret as comma-separated Telegram user IDs.
