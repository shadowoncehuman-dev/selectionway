---
name: PyPI "telegram" name collision
description: Why the pip package literally named "telegram" must never be installed alongside python-telegram-bot.
---

There's an unrelated, unmaintained PyPI package literally named `telegram` (v0.0.1). It installs files into
the same `telegram/` site-packages directory that `python-telegram-bot` uses. Installing or uninstalling one
while the other is present corrupts the shared directory — typically leaving `telegram/__init__.py` missing,
turning it into a namespace package, and breaking `from telegram import Update` with a confusing
"cannot import name 'Update' from 'telegram' (unknown location)" error.

**Why:** Discovered when a requirements.txt for a `python-telegram-bot` project accidentally listed `telegram`
as a dependency (likely from autocomplete/LLM confusion) — every reinstall attempt re-broke the module until
the bogus package was removed and `python-telegram-bot` was cleanly reinstalled.

**How to apply:** Never add a bare `telegram` dependency to a Python project that uses `python-telegram-bot`.
If this import error appears, check `pip show telegram` — if it exists alongside `python-telegram-bot`,
uninstall `telegram` and reinstall `python-telegram-bot` to restore its files.
