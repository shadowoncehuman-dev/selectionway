import os
import re
import json
import html
import sqlite3
import threading
import requests
import logging
from datetime import datetime, timezone, timedelta
from zoneinfo import ZoneInfo
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, urljoin, parse_qs, quote
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, BotCommand, WebAppInfo
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes

# Bot Configuration
BOT_TOKEN = os.environ.get("BOT_TOKEN")
if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN environment variable is not set. Add it as a secret.")

# Admin IDs — comma-separated Telegram user IDs in the ADMIN_IDS env var
# e.g.  ADMIN_IDS=123456789,987654321
_admin_ids_raw = os.environ.get("ADMIN_IDS", "")
ADMIN_IDS: set[int] = {int(x.strip()) for x in _admin_ids_raw.split(",") if x.strip().isdigit()}

DB_PATH = os.path.join(os.path.dirname(__file__), "bot_data.db")

# Enable logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

MAX_MESSAGE_LENGTH = 3500

# ──────────────────────────────────────────────────────────────
# Database helpers
# ──────────────────────────────────────────────────────────────

def _get_db():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with _get_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            user_id      INTEGER PRIMARY KEY,
            username     TEXT,
            first_name   TEXT,
            is_banned    INTEGER DEFAULT 0,
            fetch_limit  INTEGER DEFAULT 1,
            fetch_period TEXT    DEFAULT 'day',
            joined_at    TEXT    DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS fetch_log (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            batch_id    TEXT,
            batch_name  TEXT,
            fetched_at  TEXT DEFAULT (datetime('now'))
        );
        """)


def db_ensure_user(user_id: int, username: str = "", first_name: str = ""):
    """Insert user if not present; update display fields if they changed."""
    with _get_db() as db:
        db.execute("""
            INSERT INTO users (user_id, username, first_name)
            VALUES (?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                username   = excluded.username,
                first_name = excluded.first_name
        """, (user_id, username or "", first_name or ""))


def db_get_user(user_id: int):
    with _get_db() as db:
        return db.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)).fetchone()


def db_all_users():
    with _get_db() as db:
        return db.execute("SELECT * FROM users ORDER BY joined_at DESC").fetchall()


def db_set_banned(user_id: int, banned: bool):
    with _get_db() as db:
        db.execute("UPDATE users SET is_banned = ? WHERE user_id = ?", (1 if banned else 0, user_id))


def db_set_limit(user_id: int, limit: int, period: str):
    with _get_db() as db:
        db.execute("UPDATE users SET fetch_limit = ?, fetch_period = ? WHERE user_id = ?",
                   (limit, period, user_id))


def db_log_fetch(user_id: int, batch_id: str, batch_name: str):
    with _get_db() as db:
        db.execute("INSERT INTO fetch_log (user_id, batch_id, batch_name) VALUES (?, ?, ?)",
                   (user_id, batch_id, batch_name))


def db_fetch_count_in_period(user_id: int, period: str) -> int:
    """Count fetches by user_id within the given period ('day', 'week', 'month')."""
    if period == "unlimited":
        return 0
    now_utc = datetime.now(timezone.utc)
    if period == "day":
        since = (now_utc - timedelta(days=1)).isoformat()
    elif period == "week":
        since = (now_utc - timedelta(weeks=1)).isoformat()
    elif period == "month":
        since = (now_utc - timedelta(days=30)).isoformat()
    else:
        return 0
    with _get_db() as db:
        row = db.execute(
            "SELECT COUNT(*) FROM fetch_log WHERE user_id = ? AND fetched_at >= ?",
            (user_id, since)
        ).fetchone()
    return row[0] if row else 0


def db_user_fetch_history(user_id: int, limit: int = 10):
    with _get_db() as db:
        return db.execute(
            "SELECT batch_name, fetched_at FROM fetch_log WHERE user_id = ? ORDER BY fetched_at DESC LIMIT ?",
            (user_id, limit)
        ).fetchall()


def db_stats():
    with _get_db() as db:
        total = db.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        banned = db.execute("SELECT COUNT(*) FROM users WHERE is_banned=1").fetchone()[0]
        fetches = db.execute("SELECT COUNT(*) FROM fetch_log").fetchone()[0]
        today_fetches = db.execute(
            "SELECT COUNT(*) FROM fetch_log WHERE fetched_at >= datetime('now','-1 day')"
        ).fetchone()[0]
    return {"total": total, "banned": banned, "fetches": fetches, "today": today_fetches}


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


PERIOD_LABELS = {"day": "per day", "week": "per week", "month": "per month", "unlimited": "unlimited"}

# Matches a batch link like:
# https://www.selectionway.com/batches/Railway-Foundation-6.0/6a4e376d5bac0ae4bab5a040
BATCH_LINK_ID_RE = re.compile(r'/batches/[^/]+/([a-fA-F0-9]{16,32})')
RAW_ID_RE = re.compile(r'^[a-fA-F0-9]{16,32}$')


def extract_batch_id_from_text(text):
    """Return a batch id if `text` is a selectionway.com batch link or a raw id, else None."""
    text = text.strip()
    match = BATCH_LINK_ID_RE.search(text)
    if match:
        return match.group(1)
    if RAW_ID_RE.match(text):
        return text
    return None


def sort_batches_by_recency(batches):
    """Sort batches so the most recently added/updated ones come first."""
    def sort_key(course):
        return course.get('updatedAt') or course.get('createdAt') or ''
    return sorted(batches, key=sort_key, reverse=True)


IST = ZoneInfo("Asia/Kolkata")

DAY_ALIASES = {
    'mon': 0, 'tue': 1, 'tues': 1, 'wed': 2, 'thu': 3, 'thur': 3, 'thurs': 3,
    'fri': 4, 'sat': 5, 'sun': 6,
}

TIME_RANGE_RE = re.compile(
    r'(\d{1,2}:\d{2}\s*[APap][Mm])\s*-\s*(\d{1,2}:\d{2}\s*[APap][Mm])\s*\(([^)]*)\)'
)

YOUTUBE_ID_RE = re.compile(
    r'(?:youtube\.com/(?:watch\?v=|embed/|shorts/)|youtu\.be/)([A-Za-z0-9_-]{6,})'
)


def _parse_time_12h(text):
    text = text.strip().upper().replace(' ', '')
    return datetime.strptime(text, "%I:%M%p").time()


def _expand_days(day_text):
    """Parse a day range/list like 'Mon -Fri', 'MON - FRI', 'Sat, Sun' into weekday ints (Mon=0)."""
    days = set()
    for part in re.split(r'[,&]', day_text or ''):
        part = part.strip()
        if not part:
            continue
        if '-' in part:
            bounds = [p.strip()[:3].lower() for p in part.split('-', 1)]
            start, end = DAY_ALIASES.get(bounds[0]), DAY_ALIASES.get(bounds[1])
            if start is None or end is None:
                continue
            d = start
            while True:
                days.add(d)
                if d == end:
                    break
                d = (d + 1) % 7
        else:
            key = part[:3].lower()
            if key in DAY_ALIASES:
                days.add(DAY_ALIASES[key])
    return days


def is_batch_live_now(batch):
    """True if `batch` has a scheduled live session happening right now, based on its timeTable (IST)."""
    if not batch.get('isLive') or not batch.get('isTimeTable'):
        return False
    now = datetime.now(IST)
    today = now.weekday()
    now_time = now.time()
    for slot in batch.get('timeTable') or []:
        match = TIME_RANGE_RE.search(slot.get('time') or '')
        if not match:
            continue
        try:
            start_t = _parse_time_12h(match.group(1))
            end_t = _parse_time_12h(match.group(2))
        except ValueError:
            continue
        if today not in _expand_days(match.group(3)):
            continue
        if start_t <= end_t:
            if start_t <= now_time <= end_t:
                return True
        elif now_time >= start_t or now_time <= end_t:
            return True
    return False


def is_class_live_now(class_item):
    """True if this specific class's own start/end window (UTC) covers the current moment."""
    if not class_item.get('isLive'):
        return False
    start_raw, end_raw = class_item.get('startDate'), class_item.get('endDate')
    if not start_raw or not end_raw:
        return False
    try:
        start = datetime.fromisoformat(start_raw.replace('Z', '+00:00'))
        end = datetime.fromisoformat(end_raw.replace('Z', '+00:00'))
    except ValueError:
        return False
    return start <= datetime.now(timezone.utc) <= end


def extract_youtube_id(url):
    match = YOUTUBE_ID_RE.search(url or '')
    return match.group(1) if match else None


def search_batches(batches, query):
    """Filter batches by a case-insensitive match against title/category/description."""
    q = query.strip().lower()
    if not q:
        return []
    results = []
    for course in batches:
        title = (course.get('title') or '').lower()
        category = ((course.get('mainCategory') or {}).get('mainCategoryName') or '').lower()
        description = (course.get('short_description') or '').lower()
        if q in title or q in category or q in description:
            results.append(course)
    return results


async def send_long_message(target, text, parse_mode='Markdown'):
    """Send `text` via `target.reply_text`/`edit_message_text`, splitting into chunks if needed."""
    lines = text.split('\n')
    chunks = []
    current = ""
    for line in lines:
        candidate = f"{current}\n{line}" if current else line
        if len(candidate) > MAX_MESSAGE_LENGTH:
            if current:
                chunks.append(current)
            current = line
        else:
            current = candidate
    if current:
        chunks.append(current)

    for chunk in chunks:
        await target.reply_text(chunk, parse_mode=parse_mode)


class SelectionWayBot:
    def __init__(self):
        self.base_headers = {
            "sec-ch-ua-platform": "\"Windows\"",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
            "sec-ch-ua": "\"Chromium\";v=\"140\", \"Not=A?Brand\";v=\"24\", \"Google Chrome\";v=\"140\"",
            "content-type": "application/json",
            "sec-ch-ua-mobile": "?0",
            "accept": "*/*",
            "origin": "https://www.selectionway.com",
            "sec-fetch-site": "cross-site",
            "sec-fetch-mode": "cors",
            "sec-fetch-dest": "empty",
            "referer": "https://www.selectionway.com/",
            "accept-encoding": "gzip, deflate",
            "accept-language": "en-US,en;q=0.9",
            "priority": "u=1, i"
        }
        self.user_sessions = {}

    def clean_url(self, url):
        """Clean URL by removing spaces"""
        if not url:
            return ""
        return url.replace(" ", "%20")

    async def get_all_batches(self):
        """Get all active batches without login"""
        courses_url = "https://backend.multistreaming.site/api/courses/active?userId=1448640"

        courses_headers = {
            "host": "backend.multistreaming.site",
            **self.base_headers
        }

        try:
            session = requests.Session()
            response = session.get(courses_url, headers=courses_headers)
            response.raise_for_status()

            courses_response = response.json()
            if courses_response.get("state") == 200:
                return True, courses_response["data"]
            else:
                return False, "Failed to get batches"

        except Exception as e:
            return False, f"Error: {str(e)}"

    async def get_my_batches(self, user_id):
        """Get user's own batches after login"""
        if user_id not in self.user_sessions:
            return False, "Please login first"

        user_data = self.user_sessions[user_id]
        courses_url = "https://backend.multistreaming.site/api/courses/my-courses"

        courses_headers = {
            "host": "backend.multistreaming.site",
            "content-length": "20",
            **self.base_headers
        }

        courses_data = {
            "userId": str(user_data['user_id'])
        }

        try:
            response = user_data['session'].post(courses_url, headers=courses_headers, json=courses_data)
            response.raise_for_status()

            courses_response = response.json()
            if courses_response.get("state") == "200":
                return True, courses_response["data"]
            else:
                return False, "Failed to get your courses"

        except Exception as e:
            return False, f"Error: {str(e)}"

    async def login_user(self, email, password, user_id):
        """Login to SelectionWay"""
        login_url = "https://selectionway.hranker.com/admin/api/user-login"

        login_headers = {
            "host": "selectionway.hranker.com",
            "content-length": "106",
            **self.base_headers
        }

        login_data = {
            "email": email,
            "password": password,
            "mobile": "",
            "otp": "",
            "logged_in_via": "web",
            "customer_id": 561
        }

        try:
            session = requests.Session()
            response = session.post(login_url, headers=login_headers, json=login_data)
            response.raise_for_status()

            login_response = response.json()
            if login_response.get("state") == 200:
                user_data = {
                    'user_id': login_response["data"]["user_id"],
                    'token': login_response["data"]["token_id"],
                    'session': session
                }
                self.user_sessions[user_id] = user_data
                return True, "✅ Login successful!"
            else:
                return False, "❌ Login failed: Invalid credentials"

        except Exception as e:
            return False, f"❌ Login error: {str(e)}"

    async def extract_course_data_without_login(self, course_id, course_name):
        """Extract course data without login"""
        try:
            # Get course classes directly without login
            classes_url = f"https://backend.multistreaming.site/api/courses/{course_id}/classes?populate=full"
            classes_headers = {
                "host": "backend.multistreaming.site",
                **self.base_headers
            }

            session = requests.Session()
            response = session.get(classes_url, headers=classes_headers)
            response.raise_for_status()

            classes_response = response.json()
            if classes_response.get("state") == 200:
                # Get batch metadata (thumbnail, description, price…) from the public list
                all_batches_success, all_batches = await self.get_all_batches()
                pdf_url = ""
                batch_meta = {"title": course_name}

                if all_batches_success:
                    for batch in all_batches:
                        if batch.get('id') == course_id:
                            pdf_url = self.clean_url(batch.get('batchInfoPdfUrl', ""))
                            batch_meta = batch
                            break

                return True, {
                    "classes_data": classes_response["data"],
                    "pdf_url": pdf_url,
                    "course_details": batch_meta,
                    "batch_id": course_id,
                }
            else:
                return False, "Failed to get course data"

        except Exception as e:
            return False, f"Error: {str(e)}"

    async def extract_course_data_with_login(self, user_id, course_id, course_name):
        """Extract course data with login"""
        if user_id not in bot.user_sessions:
            return False, "Please login first!"

        user_data = self.user_sessions[user_id]

        # Get course details first
        course_url = "https://backend.multistreaming.site/api/courses/by-id-2"
        course_headers = {
            "host": "backend.multistreaming.site",
            "content-length": "52",
            **self.base_headers
        }

        course_data = {
            "userId": str(user_data['user_id']),
            "id": course_id
        }

        try:
            # Get course details
            response = user_data['session'].post(course_url, headers=course_headers, json=course_data)
            course_response = response.json()

            if course_response.get("state") != 200:
                return False, "Failed to get course details"

            course_details = course_response["data"]
            pdf_url = self.clean_url(course_details.get("batchInfoPdfUrl", ""))

            # Get course classes
            classes_url = f"https://backend.multistreaming.site/api/courses/{course_id}/classes?populate=full"
            classes_headers = {
                "host": "backend.multistreaming.site",
                **self.base_headers
            }

            response = user_data['session'].get(classes_url, headers=classes_headers)
            response.raise_for_status()

            classes_response = response.json()
            if classes_response.get("state") == 200:
                return True, {
                    "classes_data": classes_response["data"],
                    "pdf_url": pdf_url,
                    "course_details": course_details
                }
            else:
                return False, "Failed to get course data"

        except Exception as e:
            return False, f"Error: {str(e)}"

    def format_batches_list(self, courses_data, list_type="all"):
        """Format batches list for display"""
        if not courses_data:
            return "No batches found!", []

        if list_type == "all":
            message = "📚 *All Available Batches* (newest first)\n\n"
        else:
            message = "📚 *Your Batches*\n\n"

        batch_list = []

        # Extract all batches from response
        if list_type == "all":
            # For all batches, courses_data is direct list
            for course in courses_data:
                batch_list.append(course)
        else:
            # For my batches, courses_data has nested structure
            for course_group in courses_data:
                live_courses = course_group.get("liveCourses", [])
                recorded_courses = course_group.get("recordedCourses", [])

                for course in live_courses + recorded_courses:
                    batch_list.append(course)

        if not batch_list:
            return "❌ No batches found!", []

        for i, course in enumerate(batch_list, 1):
            title = course.get('title', 'Unknown')
            course_id = course.get('id', 'N/A')
            price = course.get('discountPrice', course.get('price', 'N/A'))
            category = course.get('mainCategory', {}).get('mainCategoryName', 'General')
            if is_batch_live_now(course):
                course_type = "🔴 LIVE NOW"
            elif course.get('isLive'):
                course_type = "⏰ LIVE (off-air)"
            else:
                course_type = "📹 RECORDED"

            message += f"*{i}. {title}*\n"
            message += f"   🆔 `{course_id}`\n"
            message += f"   📁 {category}\n"
            message += f"   💰 ₹{price} | {course_type}\n"
            message += f"   📖 {course.get('short_description', 'No description')}\n\n"

        if list_type == "my":
            message += "👉 Reply with batch number to extract (e.g., `1`)"
        else:
            message += (
                "👉 Reply with a *number* to extract, type a *search term* to filter, "
                "or paste a *batch link* (e.g. `https://www.selectionway.com/batches/Railway-Foundation-6.0/6a4e376d5bac0ae4bab5a040`)"
            )

        return message, batch_list

    def extract_all_data(self, classes_data, pdf_url, course_details):
        """Extract data from a course, grouped by topic (like the app's Classes screen).

        Returns a dict with:
          - topics: [{name, teacher, classes: [{title, duration_text, date_text,
                     pdfs, tests, video_index}]}]   (Classes tab)
          - video_links: flat list (index-aligned with video_index above) used to
                     drive the in-page player
          - pdf_links: every PDF, each tagged with its topic (Sheets tab)
          - test_links: every classTest entry, tagged with its topic (Tests tab)
        """
        video_links = []
        pdf_links = []
        test_links = []
        topics = []

        if pdf_url:
            pdf_links.append({"name": "Batch Info PDF", "url": pdf_url, "topic": "Batch Info"})

        QUALITY_ORDER = ["720p", "480p", "360p", "240p"]

        if classes_data and "classes" in classes_data:
            for topic_group in classes_data["classes"]:
                topic_name = topic_group.get("topicName") or "General"
                topic_classes = []
                topic_teacher = ""

                for class_item in topic_group.get("classes", []):
                    title = class_item.get("title", "Unknown Title")
                    teacher = class_item.get("teacherName") or ""
                    if teacher and not topic_teacher:
                        topic_teacher = teacher

                    mp4_recordings = class_item.get("mp4Recordings", []) or []
                    class_link = self.clean_url(class_item.get("class_link", ""))
                    live_now = is_class_live_now(class_item)

                    # Collect every available mp4 quality (best first) so the page can
                    # automatically fall back to a lower quality if one URL errors out.
                    by_quality = {r.get("quality"): self.clean_url(r.get("url", "")) for r in mp4_recordings if r.get("url")}
                    mp4_urls = [by_quality[q] for q in QUALITY_ORDER if q in by_quality]
                    for q, u in by_quality.items():
                        if q not in QUALITY_ORDER and u not in mp4_urls:
                            mp4_urls.append(u)

                    if mp4_urls:
                        video_type = "mp4"
                        display_quality = next((q for q in QUALITY_ORDER if q in by_quality), "SD")
                    elif live_now and class_link:
                        video_type = "hls" if ".m3u8" in class_link else ("youtube" if extract_youtube_id(class_link) else "link")
                        display_quality = "LIVE"
                    elif extract_youtube_id(class_link):
                        video_type = "youtube"
                        display_quality = "YouTube"
                    elif ".m3u8" in class_link:
                        video_type = "hls"
                        display_quality = "HLS"
                    elif class_link:
                        video_type = "link"
                        display_quality = "External"
                    else:
                        video_type = "none"
                        display_quality = ""

                    video_index = len(video_links)
                    video_links.append({
                        "title": title,
                        "quality": display_quality,
                        "video_type": video_type,
                        "mp4_urls": mp4_urls,
                        "url": class_link,
                        "live": live_now,
                        "playable": video_type in ("mp4", "youtube", "hls"),
                    })

                    class_pdfs = []
                    for pdf in class_item.get("classPdf", []) or []:
                        pdf_name = pdf.get("name") or title
                        pdf_url_item = pdf.get("url")
                        if pdf_url_item:
                            entry = {"name": pdf_name, "url": pdf_url_item, "topic": topic_name}
                            pdf_links.append(entry)
                            class_pdfs.append(entry)

                    class_tests = []
                    for test in class_item.get("classTest", []) or []:
                        test_name = test.get("name") or test.get("title") or title
                        test_url = test.get("url") or test.get("link")
                        entry = {"name": test_name, "url": test_url, "topic": topic_name}
                        test_links.append(entry)
                        class_tests.append(entry)

                    duration_seconds = class_item.get("duration")
                    duration_text = f"{duration_seconds / 60:.1f} minutes" if duration_seconds else ""

                    date_raw = class_item.get("startDate") or class_item.get("classCreatedAt")
                    date_text = ""
                    if date_raw:
                        try:
                            date_text = datetime.fromisoformat(date_raw.replace('Z', '+00:00')).strftime("%d-%b-%Y")
                        except ValueError:
                            date_text = ""

                    topic_classes.append({
                        "title": title,
                        "duration_text": duration_text,
                        "date_text": date_text,
                        "pdfs": class_pdfs,
                        "tests": class_tests,
                        "video_index": video_index,
                        "live": live_now,
                    })

                if topic_classes:
                    topics.append({
                        "name": topic_name,
                        "teacher": topic_teacher,
                        "classes": topic_classes,
                    })

        return {
            "topics": topics,
            "video_links": video_links,
            "pdf_links": pdf_links,
            "test_links": test_links,
            "course_details": course_details,   # full batch metadata for HTML header
        }

    def create_course_file(self, course_name, page_data):
        """Create a self-contained HTML file that mirrors the app's own layout:
        Classes / Sheets / Tests tabs, lectures grouped by topic (with teacher name),
        and a Watch + View PDF action per lecture — instead of one flat dump.

        Playback details:
          - mp4 lectures get a native <video> with every available quality as a
            fallback chain (auto-retries a lower quality if one URL errors out).
          - YouTube lectures get a real embedded iframe.
          - HLS (.m3u8) lectures — including a live class while it's actually on
            air — are routed through this bot's own /hls proxy and played via
            hls.js. Plain hls.js can't reach this CDN directly: it fetches
            playlists/segments with XHR, and the CDN never sends
            Access-Control-Allow-Origin, so every non-Safari browser silently
            fails. The proxy re-serves the same bytes with CORS headers added.
        """
        topics = page_data["topics"]
        video_links = page_data["video_links"]
        pdf_links = page_data["pdf_links"]
        test_links = page_data["test_links"]

        clean_name = "".join(c for c in course_name if c.isalnum() or c in (' ', '-', '_')).rstrip()
        filename = f"{clean_name.replace(' ', '_') or 'course'}.html"

        safe_course_name = html.escape(course_name)
        needs_hls = any(v["video_type"] == "hls" for v in video_links)

        # ---- Classes tab: accordion of topics, each with lecture rows ----
        topic_blocks = []
        for t_idx, topic in enumerate(topics):
            safe_topic = html.escape(topic["name"])
            safe_teacher = html.escape(topic["teacher"]) if topic["teacher"] else ""
            teacher_html = f'<span class="topic-teacher">{safe_teacher}</span>' if safe_teacher else ""

            row_blocks = []
            for cls in topic["classes"]:
                safe_title = html.escape(cls["title"])
                live_badge = ' <span class="live-badge">🔴 LIVE</span>' if cls["live"] else ""
                meta_parts = [p for p in (cls["duration_text"], cls["date_text"]) if p]
                meta_html = html.escape(" · ".join(meta_parts))

                video_index = cls["video_index"]
                video = video_links[video_index]
                if video["playable"]:
                    watch_btn = f'<button class="btn-watch" onclick="playVideo({video_index})">▶ Watch</button>'
                else:
                    watch_btn = '<span class="btn-disabled">❌ Unavailable</span>'

                pdf_btns = "".join(
                    f'<a class="btn-pdf" href="{html.escape(pdf["url"], quote=True)}" target="_blank" rel="noopener">📄 View PDF</a>'
                    for pdf in cls["pdfs"] if pdf.get("url")
                )

                row_blocks.append(
                    '<div class="lecture-row">\n'
                    '  <div class="lecture-info">\n'
                    f'    <div class="lecture-title">{safe_title}{live_badge}</div>\n'
                    f'    <div class="lecture-meta">{meta_html}</div>\n'
                    '  </div>\n'
                    f'  <div class="lecture-actions">{watch_btn}{pdf_btns}</div>\n'
                    '</div>\n'
                )

            topic_blocks.append(
                '<div class="topic-group">\n'
                f'  <button class="topic-header" onclick="toggleTopic(this)">\n'
                f'    <span class="topic-name">{safe_topic}</span>\n'
                f'    {teacher_html}\n'
                f'    <span class="topic-count">{len(topic["classes"])} classes</span>\n'
                f'    <span class="chevron">›</span>\n'
                '  </button>\n'
                f'  <div class="topic-body"{"" if t_idx == 0 else " hidden"}>\n'
                f'{"".join(row_blocks)}'
                '  </div>\n'
                '</div>\n'
            )

        classes_tab_html = "".join(topic_blocks) if topic_blocks else '<p class="empty-tab">No classes yet.</p>'

        # ---- Sheets tab: every PDF, grouped by topic ----
        pdf_by_topic = {}
        for pdf in pdf_links:
            pdf_by_topic.setdefault(pdf.get("topic") or "General", []).append(pdf)

        sheet_blocks = []
        for topic_name, pdfs in pdf_by_topic.items():
            items = "".join(
                f'<li><a href="{html.escape(pdf["url"], quote=True)}" target="_blank" rel="noopener">📄 {html.escape(pdf["name"])}</a></li>\n'
                for pdf in pdfs
            )
            sheet_blocks.append(f'<h4>{html.escape(topic_name)}</h4>\n<ul class="sheet-list">\n{items}</ul>\n')

        sheets_tab_html = "".join(sheet_blocks) if sheet_blocks else '<p class="empty-tab">No sheets available yet.</p>'

        # ---- Tests tab: every classTest entry, grouped by topic ----
        test_by_topic = {}
        for test in test_links:
            test_by_topic.setdefault(test.get("topic") or "General", []).append(test)

        test_blocks = []
        for topic_name, tests in test_by_topic.items():
            items = "".join(
                f'<li><a href="{html.escape(test["url"], quote=True)}" target="_blank" rel="noopener">📝 {html.escape(test["name"])}</a></li>\n'
                if test.get("url") else f'<li>📝 {html.escape(test["name"])}</li>\n'
                for test in tests
            )
            test_blocks.append(f'<h4>{html.escape(topic_name)}</h4>\n<ul class="sheet-list">\n{items}</ul>\n')

        tests_tab_html = "".join(test_blocks) if test_blocks else '<p class="empty-tab">No tests available yet.</p>'

        # ---- Batch metadata header (thumbnail + key facts) ----
        cd = page_data.get("course_details") or {}
        thumb_url = html.escape(cd.get("bannerSquare") or cd.get("banner") or "", quote=True)
        thumb_html = f'<img class="batch-thumb" src="{thumb_url}" alt="Batch thumbnail">' if thumb_url else ""

        desc_items = cd.get("description") or []
        if isinstance(desc_items, str):
            desc_items = [desc_items]
        highlights = cd.get("courseHighlights") or []
        desc_html = "".join(f'<li>{html.escape(str(d))}</li>' for d in desc_items[:6] if d)
        hl_html   = "".join(f'<li>{html.escape(str(h))}</li>' for h in highlights[:5] if h)

        price_val = cd.get("discountPrice") or cd.get("price") or ""
        validity  = html.escape(str(cd.get("validity") or ""))
        category  = html.escape(str((cd.get("mainCategory") or {}).get("mainCategoryName") or ""))
        faculty   = html.escape(str((cd.get("facultyDetails") or {}).get("name") or ""))
        total_cls = cd.get("liveClassesCount") or len(video_links)
        short_desc = html.escape(str(cd.get("short_description") or ""))

        batch_header_html = f"""
<div class="batch-header">
  {thumb_html}
  <div class="batch-meta">
    <div class="batch-category">{category}</div>
    <h1 class="batch-title">🎯 {safe_course_name}</h1>
    <p class="batch-short">{short_desc}</p>
    <div class="batch-chips">
      {"<span class='chip'>💰 ₹" + html.escape(str(price_val)) + "</span>" if price_val else ""}
      {"<span class='chip'>📅 " + validity + "</span>" if validity else ""}
      {"<span class='chip'>👨‍🏫 " + faculty + "</span>" if faculty else ""}
      <span class='chip'>🎥 {total_cls} classes</span>
      <span class='chip'>📄 {len(pdf_links)} PDFs</span>
    </div>
    {"<ul class='meta-list'>" + desc_html + "</ul>" if desc_html else ""}
    {"<ul class='meta-list highlights'>" + hl_html + "</ul>" if hl_html else ""}
  </div>
</div>
"""

        # ---- Player data for the lazy-loaded modal ----
        player_data = []
        for video in video_links:
            entry = dict(video)
            if entry["video_type"] == "hls" and entry["url"]:
                entry["url"] = proxied_hls_url(entry["url"])
            player_data.append(entry)
        # Embedded directly inside a <script> block (JS context, not HTML), so escape
        # only the sequence that could prematurely close the script tag.
        player_data_json = json.dumps(player_data).replace("</", "<\\/")

        hls_script_tag = (
            '<script src="https://cdn.jsdelivr.net/npm/hls.js@1/dist/hls.min.js"></script>\n' if needs_hls else ""
        )

        page = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{safe_course_name}</title>
{hls_script_tag}<style>
  * {{ box-sizing: border-box; }}
  body {{ font-family: -apple-system, Segoe UI, Roboto, Arial, sans-serif; background: #0f1115; color: #f1f1f1; margin: 0; padding: 0; }}
  /* ── Batch header ── */
  .batch-header {{ display: flex; gap: 20px; align-items: flex-start; background: #131720; border-bottom: 1px solid #21242c; padding: 20px; flex-wrap: wrap; }}
  .batch-thumb {{ width: 160px; height: 100px; object-fit: cover; border-radius: 10px; flex-shrink: 0; background: #21242c; }}
  .batch-meta {{ flex: 1; min-width: 220px; }}
  .batch-category {{ color: #4dabf7; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: .06em; margin-bottom: 4px; }}
  .batch-title {{ font-size: 1.3rem; margin: 0 0 6px; }}
  .batch-short {{ color: #8a93a3; font-size: 0.85rem; margin: 0 0 10px; }}
  .batch-chips {{ display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 10px; }}
  .chip {{ background: #21242c; border-radius: 20px; padding: 3px 10px; font-size: 0.78rem; color: #c4cad4; }}
  .meta-list {{ margin: 6px 0 0; padding-left: 18px; color: #8a93a3; font-size: 0.8rem; line-height: 1.7; }}
  .highlights li::before {{ content: "✓ "; color: #4dabf7; }}
  /* ── Content area ── */
  .content {{ padding: 16px 20px; }}
  .tabs {{ display: flex; gap: 8px; border-bottom: 1px solid #2a2d34; margin-bottom: 16px; }}
  .tab-btn {{ background: none; border: none; color: #8a93a3; font-size: 0.95rem; font-weight: 600; padding: 10px 16px; cursor: pointer; border-bottom: 2px solid transparent; }}
  .tab-btn.active {{ color: #4dabf7; border-bottom-color: #4dabf7; }}
  .tab-panel {{ display: none; }}
  .tab-panel.active {{ display: block; }}
  .empty-tab {{ color: #8a93a3; padding: 24px 0; }}
  .topic-group {{ margin-bottom: 10px; background: #171a21; border-radius: 10px; overflow: hidden; }}
  .topic-header {{ width: 100%; display: flex; align-items: center; gap: 10px; background: none; border: none; color: #f1f1f1; padding: 14px 16px; font-size: 0.95rem; cursor: pointer; text-align: left; }}
  .topic-name {{ font-weight: 700; }}
  .topic-teacher {{ color: #8a93a3; font-size: 0.85rem; }}
  .topic-count {{ margin-left: auto; color: #8a93a3; font-size: 0.8rem; white-space: nowrap; }}
  .chevron {{ transition: transform 0.15s; color: #8a93a3; }}
  .topic-header.open .chevron {{ transform: rotate(90deg); }}
  .topic-body {{ border-top: 1px solid #21242c; }}
  .lecture-row {{ display: flex; align-items: center; gap: 12px; padding: 12px 16px; border-bottom: 1px solid #21242c; }}
  .lecture-row:last-child {{ border-bottom: none; }}
  .lecture-info {{ flex: 1; min-width: 0; }}
  .lecture-title {{ font-size: 0.88rem; word-break: break-word; }}
  .lecture-meta {{ color: #8a93a3; font-size: 0.75rem; margin-top: 3px; }}
  .live-badge {{ color: #ff4d4f; font-weight: bold; }}
  .lecture-actions {{ display: flex; gap: 6px; flex-shrink: 0; flex-wrap: wrap; justify-content: flex-end; }}
  .btn-watch {{ background: #4dabf7; color: #0f1115; border: none; border-radius: 6px; padding: 6px 13px; font-size: 0.8rem; font-weight: 700; cursor: pointer; white-space: nowrap; }}
  .btn-pdf {{ background: #21242c; color: #c4cad4; border-radius: 6px; padding: 6px 13px; font-size: 0.8rem; text-decoration: none; white-space: nowrap; }}
  .btn-disabled {{ color: #5a6070; font-size: 0.8rem; }}
  .sheet-list {{ line-height: 1.9; margin: 0 0 16px; padding-left: 18px; }}
  .sheet-list a {{ color: #4dabf7; text-decoration: none; }}
  h4 {{ color: #c4cad4; margin: 16px 0 4px; font-size: 0.9rem; }}
  /* ── Player modal ── */
  #player-modal {{ position: fixed; inset: 0; background: rgba(0,0,0,0.88); display: flex; align-items: center; justify-content: center; z-index: 100; padding: 16px; }}
  #player-modal[hidden] {{ display: none; }}
  .modal-content {{ background: #171a21; border-radius: 12px; padding: 16px; width: 100%; max-width: 940px; }}
  .modal-top {{ display: flex; align-items: flex-start; gap: 8px; margin-bottom: 12px; }}
  .modal-close {{ background: #21242c; border: none; color: #f1f1f1; font-size: 1rem; cursor: pointer; border-radius: 6px; padding: 4px 10px; flex-shrink: 0; }}
  #player-title {{ margin: 0; font-size: 0.95rem; flex: 1; }}
  .player-frame {{ width: 100%; aspect-ratio: 16 / 9; background: #000; border-radius: 8px; overflow: hidden; }}
  .player-frame video, .player-frame iframe {{ width: 100%; height: 100%; border: 0; display: block; }}
  .fallback-link {{ margin: 0; padding: 20px 0; text-align: center; }}
  .fallback-link a {{ color: #4dabf7; }}
</style>
</head>
<body>
{batch_header_html}
<div class="content">
<div class="tabs">
  <button class="tab-btn active" onclick="showTab('classes', this)">📚 Classes ({len(video_links)})</button>
  <button class="tab-btn" onclick="showTab('sheets', this)">📄 Sheets ({len(pdf_links)})</button>
  <button class="tab-btn" onclick="showTab('tests', this)">📝 Tests ({len(test_links)})</button>
</div>

<div id="tab-classes" class="tab-panel active">
{classes_tab_html}</div>
<div id="tab-sheets" class="tab-panel">
{sheets_tab_html}</div>
<div id="tab-tests" class="tab-panel">
{tests_tab_html}</div>
</div>

<div id="player-modal" hidden>
  <div class="modal-content">
    <div class="modal-top">
      <h3 id="player-title"></h3>
      <button class="modal-close" onclick="closePlayer()">✕ Close</button>
    </div>
    <div id="player-slot"></div>
  </div>
</div>

<script>
var VIDEOS = {player_data_json};

function showTab(name, btn) {{
  document.querySelectorAll('.tab-panel').forEach(function (el) {{ el.classList.remove('active'); }});
  document.querySelectorAll('.tab-btn').forEach(function (el) {{ el.classList.remove('active'); }});
  document.getElementById('tab-' + name).classList.add('active');
  btn.classList.add('active');
}}

function toggleTopic(btn) {{
  var body = btn.nextElementSibling;
  var hidden = body.hasAttribute('hidden');
  if (hidden) {{ body.removeAttribute('hidden'); btn.classList.add('open'); }}
  else {{ body.setAttribute('hidden', ''); btn.classList.remove('open'); }}
}}

function closePlayer() {{
  document.getElementById('player-modal').setAttribute('hidden', '');
  var slot = document.getElementById('player-slot');
  slot.innerHTML = '';
}}

function playVideo(idx) {{
  var video = VIDEOS[idx];
  document.getElementById('player-title').textContent = video.title;
  var slot = document.getElementById('player-slot');
  slot.innerHTML = '';

  if (video.video_type === 'mp4') {{
    var urls = video.mp4_urls || [];
    if (!urls.length) {{
      slot.innerHTML = '<p class="fallback-link">❌ No video URL available.</p>';
    }} else {{
      var el = document.createElement('video');
      el.controls = true;
      el.playsInline = true;
      el.style.width = '100%';
      el.style.borderRadius = '8px';
      el.style.background = '#000';
      var qIdx = 0;
      function loadUrl() {{
        el.src = urls[qIdx];
        el.load();
      }}
      el.addEventListener('error', function () {{
        qIdx++;
        if (qIdx < urls.length) {{ loadUrl(); }}
        else {{ slot.innerHTML = '<p class="fallback-link">❌ Video could not be loaded. Try opening it directly:<br>' + urls.map(function(u) {{ return '<a href="'+u+'" target="_blank">↗ '+u.split('/').slice(-1)[0]+'</a>'; }}).join('<br>') + '</p>'; }}
      }});
      loadUrl();
      var frame = document.createElement('div');
      frame.className = 'player-frame';
      frame.appendChild(el);
      slot.appendChild(frame);
    }}
  }} else if (video.video_type === 'youtube') {{
    var yt = video.url.match(/(?:youtube\\.com\\/(?:watch\\?v=|embed\\/|shorts\\/)|youtu\\.be\\/)([A-Za-z0-9_-]{{6,}})/);
    var ytId = yt ? yt[1] : '';
    var iframe = document.createElement('iframe');
    iframe.src = 'https://www.youtube.com/embed/' + ytId;
    iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
    iframe.allowFullscreen = true;
    var frame = document.createElement('div');
    frame.className = 'player-frame';
    frame.appendChild(iframe);
    slot.appendChild(frame);
  }} else if (video.video_type === 'hls') {{
    var hv = document.createElement('video');
    hv.controls = true; hv.playsInline = true;
    var frame = document.createElement('div');
    frame.className = 'player-frame';
    frame.appendChild(hv);
    slot.appendChild(frame);
    if (hv.canPlayType('application/vnd.apple.mpegurl')) {{
      hv.src = video.url;
    }} else if (window.Hls && window.Hls.isSupported()) {{
      var hls = new Hls();
      hls.loadSource(video.url);
      hls.attachMedia(hv);
    }} else {{
      slot.innerHTML = '<p class="fallback-link">❌ Your browser cannot play this stream. Try Safari, or <a href="' + video.url + '" target="_blank">open it directly</a>.</p>';
    }}
  }} else if (video.video_type === 'link') {{
    slot.innerHTML = '<p class="fallback-link"><a href="' + video.url + '" target="_blank" rel="noopener">▶️ Open video in a new tab</a></p>';
  }} else {{
    slot.innerHTML = '<p class="fallback-link">❌ No video available for this lecture.</p>';
  }}

  document.getElementById('player-modal').removeAttribute('hidden');
}}

// Close modal on backdrop click
document.getElementById('player-modal').addEventListener('click', function(e) {{
  if (e.target === this) closePlayer();
}});
</script>
</body>
</html>
"""

        with open(filename, 'w', encoding='utf-8') as f:
            f.write(page)

        return filename


HLS_PROXY_PORT = 8080


class HLSProxyHandler(BaseHTTPRequestHandler):
    """Tiny same-process proxy that re-serves HLS playlists/segments with CORS
    headers, since the CDN (selectionwaylive.hranker.com) never sends
    Access-Control-Allow-Origin, which silently blocks hls.js's XHR loader in
    every browser except Safari's native player."""

    protocol_version = "HTTP/1.1"

    def log_message(self, format, *args):
        pass  # keep this out of the bot's own logs

    def _cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "*")

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors_headers()
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path != "/hls":
            self.send_response(404)
            self._cors_headers()
            self.end_headers()
            return

        target = (parse_qs(parsed.query).get("url") or [None])[0]
        if not target:
            self.send_response(400)
            self._cors_headers()
            self.end_headers()
            return

        try:
            upstream = requests.get(target, headers={"User-Agent": "Mozilla/5.0"}, timeout=20, stream=True)
        except requests.RequestException:
            self.send_response(502)
            self._cors_headers()
            self.end_headers()
            return

        content_type = upstream.headers.get("Content-Type", "")
        if target.endswith(".m3u8") or "mpegurl" in content_type:
            text = upstream.content.decode("utf-8", "ignore")
            rewritten = []
            for line in text.splitlines():
                stripped = line.strip()
                if stripped and not stripped.startswith("#"):
                    absolute = urljoin(target, stripped)
                    rewritten.append(f"/hls?url={quote(absolute, safe='')}")
                else:
                    rewritten.append(line)
            payload = ("\n".join(rewritten) + "\n").encode("utf-8")
            self.send_response(200)
            self._cors_headers()
            self.send_header("Content-Type", "application/vnd.apple.mpegurl")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
        else:
            self.send_response(upstream.status_code)
            self._cors_headers()
            self.send_header("Content-Type", content_type or "video/mp2t")
            self.end_headers()
            try:
                for chunk in upstream.iter_content(chunk_size=65536):
                    if chunk:
                        self.wfile.write(chunk)
            except (BrokenPipeError, ConnectionResetError):
                pass


def start_hls_proxy():
    server = ThreadingHTTPServer(("0.0.0.0", HLS_PROXY_PORT), HLSProxyHandler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    logger.info(f"HLS proxy listening on port {HLS_PROXY_PORT}")


def get_proxy_base_url():
    domain = os.environ.get("REPLIT_DEV_DOMAIN")
    if domain:
        return f"https://{domain}"
    return f"http://localhost:{HLS_PROXY_PORT}"


def proxied_hls_url(raw_url):
    return f"{get_proxy_base_url()}/hls?url={quote(raw_url, safe='')}"


# Create bot instance
bot = SelectionWayBot()


async def send_all_batches(reply_target, context, header_text=None):
    """Fetch, sort and display all batches; store them in context for selection/search."""
    if header_text:
        await reply_target.reply_text(header_text)

    success, result = await bot.get_all_batches()
    if not success:
        await reply_target.reply_text(f"❌ {result}")
        return

    sorted_batches = sort_batches_by_recency(result)
    context.user_data['all_batches_full'] = sorted_batches
    context.user_data['all_batches'] = sorted_batches
    context.user_data['awaiting_batch_id'] = True
    context.user_data['action_type'] = 'all_batches'

    message, _ = bot.format_batches_list(sorted_batches, "all")
    await send_long_message(reply_target, message)


# ──────────────────────────────────────────────────────────────
# Rate-limit helper
# ──────────────────────────────────────────────────────────────

def check_rate_limit(user_id: int):
    """Returns (allowed: bool, message: str).
    Admins are never rate-limited."""
    if is_admin(user_id):
        return True, ""
    user = db_get_user(user_id)
    if not user:
        return True, ""
    if user["is_banned"]:
        return False, "🚫 You have been banned from using this bot."
    period = user["fetch_period"]
    limit  = user["fetch_limit"]
    if period == "unlimited":
        return True, ""
    count = db_fetch_count_in_period(user_id, period)
    if count >= limit:
        return False, (
            f"⏳ You've reached your fetch limit ({limit} {PERIOD_LABELS[period]}).\n"
            "Please wait for the period to reset, or ask an admin for a higher limit."
        )
    return True, ""


# ──────────────────────────────────────────────────────────────
# Admin portal helpers
# ──────────────────────────────────────────────────────────────

def admin_main_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("👥 Users", callback_data="adm:users:0"),
         InlineKeyboardButton("📊 Stats", callback_data="adm:stats")],
    ])


def admin_user_keyboard(uid: int, is_banned_flag: bool):
    ban_label = "✅ Unban" if is_banned_flag else "🚫 Ban"
    ban_cb    = f"adm:unban:{uid}" if is_banned_flag else f"adm:ban:{uid}"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(ban_label, callback_data=ban_cb),
         InlineKeyboardButton("⚙️ Set Limit", callback_data=f"adm:setlimit:{uid}")],
        [InlineKeyboardButton("🕓 History", callback_data=f"adm:history:{uid}"),
         InlineKeyboardButton("« Back", callback_data="adm:users:0")],
    ])


def fmt_user_row(u):
    name = u["first_name"] or u["username"] or f"uid:{u['user_id']}"
    badge = " 🚫" if u["is_banned"] else (" 👑" if is_admin(u["user_id"]) else "")
    limit_str = f"{u['fetch_limit']}/{PERIOD_LABELS.get(u['fetch_period'], u['fetch_period'])}"
    return f"*{name}*{badge} — `{u['user_id']}` — {limit_str}"


# ──────────────────────────────────────────────────────────────
# Telegram Bot Handlers
# ──────────────────────────────────────────────────────────────

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Greet the user, register them, then load all available batches."""
    user   = update.effective_user
    uid    = user.id
    db_ensure_user(uid, user.username or "", user.first_name or "")

    admin_flag = is_admin(uid)
    name_md = user.first_name or "there"

    if admin_flag:
        greeting = (
            f"👑 *Welcome back, Admin {name_md}!*\n\n"
            f"You have full access to the bot and admin controls.\n"
            f"Use /admin to open the admin panel.\n\n"
            f"Loading all available batches now…"
        )
    else:
        greeting = (
            f"👋 *Hello, {name_md}!* Welcome to *SelectionWay Bot*\n\n"
            f"This bot lets you browse and extract every lecture, PDF and test from any SelectionWay batch "
            f"as a single offline-playable HTML file you can open in any browser.\n\n"
            f"📌 *How to use:*\n"
            f"  • Pick a batch number from the list below\n"
            f"  • Or type a search term to filter\n"
            f"  • Or paste a batch link directly\n"
            f"  • Login first to access your enrolled batches\n\n"
            f"Loading all available batches now…"
        )

    await update.message.reply_text(greeting, parse_mode='Markdown')
    await send_all_batches(update.message, context)

    keyboard = [[InlineKeyboardButton("🔐 Login for My Batches", callback_data="login_extract")]]
    if admin_flag:
        keyboard.append([InlineKeyboardButton("🛡 Admin Panel", callback_data="adm:menu")])
    await update.message.reply_text(
        "Want to see only *your enrolled* batches instead?",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='Markdown'
    )


async def admin_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Entry point for /admin command (admins only)."""
    uid = update.effective_user.id
    if not is_admin(uid):
        await update.message.reply_text("⛔ Admin only.")
        return
    s = db_stats()
    await update.message.reply_text(
        f"🛡 *Admin Panel*\n\n"
        f"👥 Total users: *{s['total']}*\n"
        f"🚫 Banned: *{s['banned']}*\n"
        f"📦 Total fetches: *{s['fetches']}*\n"
        f"📅 Fetches (last 24 h): *{s['today']}*",
        reply_markup=admin_main_keyboard(),
        parse_mode='Markdown'
    )


async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle all inline button presses."""
    query = update.callback_query
    await query.answer()
    uid   = query.from_user.id
    data  = query.data

    # ── Regular buttons ──────────────────────────────────────
    if data == "login_extract":
        context.user_data['awaiting_login'] = True
        context.user_data['action_type'] = 'login_extract'
        await query.edit_message_text(
            "🔐 *Login Required*\n\n"
            "Please send your login credentials in this format:\n"
            "`email:password`\n\n"
            "Example:\n"
            "`9007111119:Ty28@`",
            parse_mode='Markdown'
        )
        return

    if data == "list_batches":
        await send_all_batches(query.message, context)
        return

    # ── Admin buttons — require admin privilege ───────────────
    if not data.startswith("adm:"):
        return
    if not is_admin(uid):
        await query.answer("⛔ Admin only.", show_alert=True)
        return

    parts = data.split(":")  # e.g. ['adm', 'user', '123']

    if parts[1] == "menu":
        s = db_stats()
        await query.edit_message_text(
            f"🛡 *Admin Panel*\n\n"
            f"👥 Total users: *{s['total']}*\n"
            f"🚫 Banned: *{s['banned']}*\n"
            f"📦 Total fetches: *{s['fetches']}*\n"
            f"📅 Fetches (last 24 h): *{s['today']}*",
            reply_markup=admin_main_keyboard(),
            parse_mode='Markdown'
        )

    elif parts[1] == "stats":
        s = db_stats()
        await query.edit_message_text(
            f"📊 *Bot Statistics*\n\n"
            f"👥 Total users: *{s['total']}*\n"
            f"🚫 Banned: *{s['banned']}*\n"
            f"📦 Total fetches ever: *{s['fetches']}*\n"
            f"📅 Fetches (last 24 h): *{s['today']}*",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("« Back", callback_data="adm:menu")]]),
            parse_mode='Markdown'
        )

    elif parts[1] == "users":
        page = int(parts[2]) if len(parts) > 2 else 0
        PAGE = 10
        users = db_all_users()
        total = len(users)
        chunk = users[page * PAGE:(page + 1) * PAGE]
        lines = [f"{page*PAGE + i + 1}. {fmt_user_row(u)}" for i, u in enumerate(chunk)]
        nav = []
        if page > 0:
            nav.append(InlineKeyboardButton("◀ Prev", callback_data=f"adm:users:{page-1}"))
        if (page + 1) * PAGE < total:
            nav.append(InlineKeyboardButton("Next ▶", callback_data=f"adm:users:{page+1}"))
        # Build per-user buttons (first row only to keep it compact)
        user_btns = [
            [InlineKeyboardButton(
                f"View {u['first_name'] or u['user_id']}",
                callback_data=f"adm:user:{u['user_id']}"
            )]
            for u in chunk
        ]
        kb = user_btns + ([nav] if nav else []) + [[InlineKeyboardButton("« Back", callback_data="adm:menu")]]
        await query.edit_message_text(
            f"👥 *Users* (page {page+1})\n\n" + "\n".join(lines),
            reply_markup=InlineKeyboardMarkup(kb),
            parse_mode='Markdown'
        )

    elif parts[1] == "user":
        target_uid = int(parts[2])
        u = db_get_user(target_uid)
        if not u:
            await query.answer("User not found.", show_alert=True)
            return
        hist = db_user_fetch_history(target_uid, 5)
        hist_lines = "\n".join(f"  • {r['batch_name']} ({r['fetched_at'][:10]})" for r in hist) or "  (none yet)"
        limit_str = f"{u['fetch_limit']} {PERIOD_LABELS.get(u['fetch_period'], u['fetch_period'])}"
        status = "🚫 Banned" if u['is_banned'] else "✅ Active"
        await query.edit_message_text(
            f"👤 *User Profile*\n\n"
            f"Name: {u['first_name']} (@{u['username'] or '-'})\n"
            f"ID: `{u['user_id']}`\n"
            f"Status: {status}\n"
            f"Fetch limit: {limit_str}\n"
            f"Joined: {(u['joined_at'] or '')[:10]}\n\n"
            f"📦 Recent fetches:\n{hist_lines}",
            reply_markup=admin_user_keyboard(target_uid, bool(u['is_banned'])),
            parse_mode='Markdown'
        )

    elif parts[1] in ("ban", "unban"):
        target_uid = int(parts[2])
        do_ban = parts[1] == "ban"
        db_set_banned(target_uid, do_ban)
        u = db_get_user(target_uid)
        action = "banned 🚫" if do_ban else "unbanned ✅"
        await query.answer(f"User {action}.", show_alert=False)
        # Refresh the user view
        hist = db_user_fetch_history(target_uid, 5)
        hist_lines = "\n".join(f"  • {r['batch_name']} ({r['fetched_at'][:10]})" for r in hist) or "  (none yet)"
        limit_str = f"{u['fetch_limit']} {PERIOD_LABELS.get(u['fetch_period'], u['fetch_period'])}"
        status = "🚫 Banned" if u['is_banned'] else "✅ Active"
        await query.edit_message_text(
            f"👤 *User Profile*\n\n"
            f"Name: {u['first_name']} (@{u['username'] or '-'})\n"
            f"ID: `{u['user_id']}`\n"
            f"Status: {status}\n"
            f"Fetch limit: {limit_str}\n"
            f"Joined: {(u['joined_at'] or '')[:10]}\n\n"
            f"📦 Recent fetches:\n{hist_lines}",
            reply_markup=admin_user_keyboard(target_uid, bool(u['is_banned'])),
            parse_mode='Markdown'
        )

    elif parts[1] == "history":
        target_uid = int(parts[2])
        hist = db_user_fetch_history(target_uid, 20)
        lines = "\n".join(f"• {r['batch_name']} — {r['fetched_at'][:16]}" for r in hist) or "(none)"
        await query.edit_message_text(
            f"🕓 *Fetch History* for `{target_uid}`\n\n{lines}",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("« Back", callback_data=f"adm:user:{target_uid}")]]),
            parse_mode='Markdown'
        )

    elif parts[1] == "setlimit":
        target_uid = int(parts[2])
        context.user_data['admin_setting_limit_for'] = target_uid
        await query.edit_message_text(
            f"⚙️ *Set fetch limit for user* `{target_uid}`\n\n"
            f"Send a message in this format:\n"
            f"`<count> <period>`\n\n"
            f"Examples:\n"
            f"  `1 day`  — 1 fetch per day\n"
            f"  `3 week` — 3 per week\n"
            f"  `5 month` — 5 per month\n"
            f"  `0 unlimited` — no limit\n",
            parse_mode='Markdown'
        )


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle user messages"""
    user = update.effective_user
    user_id = user.id
    text = update.message.text

    # Register user on every interaction
    db_ensure_user(user_id, user.username or "", user.first_name or "")

    # ── Admin: setting a limit for another user ─────────────────
    if context.user_data.get('admin_setting_limit_for') and is_admin(user_id):
        target_uid = context.user_data.pop('admin_setting_limit_for')
        parts = text.strip().lower().split()
        valid_periods = {"day", "week", "month", "unlimited"}
        if len(parts) == 2 and parts[0].isdigit() and parts[1] in valid_periods:
            count  = int(parts[0])
            period = parts[1]
            if period == "unlimited":
                count = 999999
            db_set_limit(target_uid, count, period)
            await update.message.reply_text(
                f"✅ Limit for `{target_uid}` set to *{count} {PERIOD_LABELS.get(period, period)}*.",
                parse_mode='Markdown'
            )
        else:
            await update.message.reply_text(
                "❌ Invalid format. Use: `<count> <period>` — e.g. `2 day` or `0 unlimited`",
                parse_mode='Markdown'
            )
        return

    if context.user_data.get('awaiting_login'):
        # Handle login credentials
        if ":" in text:
            email, password = text.split(":", 1)
            email = email.strip()
            password = password.strip()

            await update.message.reply_text("🔄 Logging in...")

            success, message = await bot.login_user(email, password, user_id)
            if success:
                context.user_data['awaiting_login'] = False

                # Get USER'S OWN batches after login
                await update.message.reply_text("🔄 Loading your batches...")
                success, my_batches = await bot.get_my_batches(user_id)

                if success:
                    formatted_list, batch_list = bot.format_batches_list(my_batches, "my")

                    if batch_list:
                        # Store user's batches in context
                        context.user_data['my_batches'] = batch_list
                        context.user_data['awaiting_batch_selection'] = True
                        await send_long_message(update.message, formatted_list)
                    else:
                        # No enrolled batches — don't trap the user in a dead numeric-selection
                        # state; fall back to browsing the full batch list instead.
                        context.user_data['awaiting_batch_selection'] = False
                        await update.message.reply_text(
                            "📭 You don't have any enrolled batches yet.\n\n"
                            "Showing all available batches instead:"
                        )
                        await send_all_batches(update.message, context)
                else:
                    await update.message.reply_text(f"✅ Login successful but {my_batches}")
            else:
                await update.message.reply_text(message)
        else:
            await update.message.reply_text(
                "❌ Invalid format! Please use:\n`email:password`",
                parse_mode='Markdown'
            )

    elif context.user_data.get('awaiting_batch_selection'):
        # Handle batch number selection (with login)
        if text.isdigit():
            batch_number = int(text)
            batch_list = context.user_data.get('my_batches', [])

            if 1 <= batch_number <= len(batch_list):
                # Rate-limit check
                allowed, rl_msg = check_rate_limit(user_id)
                if not allowed:
                    await update.message.reply_text(rl_msg)
                    return

                selected_batch = batch_list[batch_number - 1]
                course_id = selected_batch.get('id')
                course_name = selected_batch.get('title', 'Course')

                await update.message.reply_text(f"🔄 Extracting *{course_name}*...", parse_mode='Markdown')

                success, result = await bot.extract_course_data_with_login(user_id, course_id, course_name)

                if success:
                    await process_extraction_result(update, course_name, result)
                    context.user_data['awaiting_batch_selection'] = False
                else:
                    await update.message.reply_text(f"❌ {result}")
            else:
                await update.message.reply_text(f"❌ Please enter a number between 1 and {len(batch_list)}")
        else:
            await update.message.reply_text("❌ Please enter a valid number")

    elif context.user_data.get('awaiting_batch_id'):
        text_stripped = text.strip()

        # 1) A pasted batch link or a raw batch id -> extract directly, regardless of what's listed
        linked_id = extract_batch_id_from_text(text_stripped)
        if linked_id:
            allowed, rl_msg = check_rate_limit(user_id)
            if not allowed:
                await update.message.reply_text(rl_msg)
                return

            batch_list = context.user_data.get('all_batches_full', [])
            course_name = next((b.get('title', 'Unknown Course') for b in batch_list if b.get('id') == linked_id), None)

            if not course_name:
                success, refreshed = await bot.get_all_batches()
                if success:
                    context.user_data['all_batches_full'] = refreshed
                    course_name = next((b.get('title', 'Unknown Course') for b in refreshed if b.get('id') == linked_id), None)

            course_name = course_name or "Unknown Course"

            await update.message.reply_text(f"🔄 Extracting *{course_name}*...", parse_mode='Markdown')
            success, result = await bot.extract_course_data_without_login(linked_id, course_name)

            if success:
                await process_extraction_result(update, course_name, result)
                context.user_data['awaiting_batch_id'] = False
            else:
                await update.message.reply_text(f"❌ {result}")
            return

        # 2) A number -> select from the currently displayed (possibly search-filtered) list
        if text_stripped.isdigit():
            batch_number = int(text_stripped)
            batch_list = context.user_data.get('all_batches', [])

            if 1 <= batch_number <= len(batch_list):
                allowed, rl_msg = check_rate_limit(user_id)
                if not allowed:
                    await update.message.reply_text(rl_msg)
                    return

                selected_batch = batch_list[batch_number - 1]
                course_id = selected_batch.get('id')
                course_name = selected_batch.get('title', 'Course')

                await update.message.reply_text(f"🔄 Extracting *{course_name}*...", parse_mode='Markdown')

                success, result = await bot.extract_course_data_without_login(course_id, course_name)

                if success:
                    await process_extraction_result(update, course_name, result)
                    context.user_data['awaiting_batch_id'] = False
                else:
                    await update.message.reply_text(f"❌ {result}")
            else:
                await update.message.reply_text(f"❌ Please enter a number between 1 and {len(batch_list)}")
            return

        # 3) Anything else -> treat as a search query against the full batch list
        all_batches_full = context.user_data.get('all_batches_full', [])
        matches = search_batches(all_batches_full, text_stripped)

        if matches:
            context.user_data['all_batches'] = matches
            message, _ = bot.format_batches_list(matches, "all")
            await send_long_message(
                update.message,
                f"🔍 Found {len(matches)} batch(es) matching *{html.escape(text_stripped)}*:\n\n{message}"
            )
        else:
            await update.message.reply_text(
                f"❌ No batches found matching '{text_stripped}'.\n\n"
                "Try a different search term, or paste a batch link like:\n"
                "`https://www.selectionway.com/batches/Railway-Foundation-6.0/6a4e376d5bac0ae4bab5a040`",
                parse_mode='Markdown'
            )

    elif text.startswith('/'):
        await update.message.reply_text("Please use /start to begin")


async def process_extraction_result(update, course_name, result):
    """Build the HTML file, log the fetch, and send it to the user."""
    page_data = bot.extract_all_data(
        result["classes_data"],
        result["pdf_url"],
        result["course_details"]
    )

    # Create file
    filename = bot.create_course_file(course_name, page_data)

    total_videos = len(page_data["video_links"])
    total_pdfs   = len(page_data["pdf_links"])

    # Log this fetch
    uid       = update.effective_user.id
    batch_id  = result.get("batch_id", "")
    db_log_fetch(uid, batch_id, course_name)

    # Count remaining fetches for this period
    user = db_get_user(uid)
    period = user["fetch_period"] if user else "day"
    if period != "unlimited" and not is_admin(uid):
        limit   = user["fetch_limit"] if user else 1
        used    = db_fetch_count_in_period(uid, period)
        remaining = max(0, limit - used)
        quota_line = f"• ⏳ Remaining today: *{remaining}/{limit}* fetch(es)"
    else:
        quota_line = "• ⏳ Quota: *unlimited*"

    caption = (
        f"🎯 *{course_name}*\n\n"
        f"📊 *Extraction Complete!*\n"
        f"• 🎥 Videos: *{total_videos}*\n"
        f"• 📄 PDFs: *{total_pdfs}*\n"
        f"{quota_line}\n\n"
        f"✅ *Open the HTML file in any browser to watch every lecture!*\n"
        f"_Tip: click ▶ Watch next to any lecture row._"
    )

    with open(filename, 'rb') as f:
        await update.message.reply_document(
            document=f,
            filename=filename,
            caption=caption,
            parse_mode='Markdown'
        )

    os.remove(filename)


async def post_init(application):
    """Set the bot command list so Telegram shows the menu on /."""
    commands = [
        BotCommand("start", "Browse all batches & extract lectures"),
        BotCommand("admin", "Admin panel (admins only)"),
    ]
    await application.bot.set_my_commands(commands)
    logger.info("Bot commands registered.")


def main():
    """Initialise DB, start proxy, register handlers, run polling."""
    init_db()
    start_hls_proxy()

    application = (
        Application.builder()
        .token(BOT_TOKEN)
        .post_init(post_init)
        .build()
    )

    # Handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("admin", admin_cmd))
    application.add_handler(CallbackQueryHandler(button_handler))   # catches all callbacks
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    print("🤖 Bot is running…")
    application.run_polling()


if __name__ == '__main__':
    main()
